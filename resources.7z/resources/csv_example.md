```
firstname,name,address,City,city_initials,city_postal_code
John,Doe,120 jefferson st.,Riverside, NJ,8075
Jack,McGinnis,220 hobo Av.,Phila, PA,9119
"John ""Da Man""",Repici,120 Jefferson St.,Riverside, NJ,8075
Stephen,Tyler,"7452 Terrace ""At the Plaza"" road",SomeTown,SD,91234
Michael,Blankman,3th road of JK,SomeTown, SD,298
"Joan ""the bone"", Anne",Jet,"9th, at Terrace plc",Desert City,CO,123
```